RENAME TABLE dims_mod_wce_article  TO dims_mod_webedit_article;
RENAME TABLE dims_mod_wce_article_draft  TO dims_mod_webedit_article_draft;
RENAME TABLE dims_mod_wce_heading  TO dims_mod_webedit_heading;

