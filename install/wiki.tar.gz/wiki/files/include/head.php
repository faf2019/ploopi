<link href="./lib/jstoolbar/jstoolbar.css" media="screen" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="./lib/jstoolbar/jstoolbar.js"></script>
<script type="text/javascript" src="./lib/jstoolbar/textile.js"></script>
<script type="text/javascript" src="./lib/jstoolbar/lang/jstoolbar-fr.js"></script>